﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using ShFLY.DataBase.Table;
using System;

namespace ShFLU.DataBase.Table
{
    public class WagInSmgs
    {
        /// <summary>
        /// Primary Key
        /// </summary>
        public int WagonSmgsId { get; set; }
        /// <summary>
        /// Wagon
        /// </summary>
        public virtual Wagon Wagon { get; set; }
        public int WgaonId { get; set; }


        /// <summary>
        /// SMGS
        /// </summary>
        public virtual SmgsNakl SmgsNakl { get; set; }
        public int SmgsNaklId { get; set; }

        //  public virtual TaraBruttoFromMatrix TaraBruttoFromMatrix { get; set; }


        /// <summary>
        /// Tara from SMGS
        /// </summary>
        public string Tarapr { get; set; }
        /// <summary>
        /// weight Brutto
        /// </summary>
        public string Weightb { get; set; }
        /// <summary>
        /// Netto
        /// </summary>
        public string Weight { get; set; }

        public int MatrixWeigth
        {
            get { return MatrixWeigthDiff(); }
        }
        public int SmgsMatrixWeigth
        {
            get { return SmgsMatrixWeigthDiff(); }
        }
        public int MatrixSmgsBruttoDiff
        {
            get { return MatrixSmgsBruttoDiffm(); }
        }
        public int MatrixSmgsNettoDiff
        {
            get { return MatrixSmgsNettoDiffm(); }
        }

        public virtual MatrixWagon MatrixWagonTara { get; set; }
        public virtual MatrixWagon MatrixWagonBrutto { get; set; }

        private int MatrixSmgsBruttoDiffm()
        {
            int MatrixWeight = 0;

            if (MatrixWagonBrutto != null)
            {
                MatrixWeight = Convert.ToInt32(MatrixWagonBrutto.Weight);
            }
            return (
                Convert.ToInt32(Weightb) - MatrixWeight
                );

        }
        private int MatrixSmgsNettoDiffm()
        {
            int MatrixWeight = 0;

            if (MatrixWagonBrutto != null)
            {
                MatrixWeight = Convert.ToInt32(MatrixWagonTara.Weight);
            }
            return (
                Convert.ToInt32(Tarapr) - MatrixWeight
                );
        }



        private int MatrixWeigthDiff()
        {

            int Brutto = 0;
            int Tara = 0;
            if (MatrixWagonBrutto != null)
            {
                Brutto = Convert.ToInt32(MatrixWagonBrutto.Weight);
            }
            if (MatrixWagonTara != null)
            {
                Tara = Convert.ToInt32(MatrixWagonTara.Weight);
            }

            return (
               Brutto - Tara
                );
        }
        private int SmgsMatrixWeigthDiff()
        {

            return (
                (MatrixWeigthDiff() - Convert.ToInt32(this.Weight))
                );
        }
    }

    public class WagInSmgsConfiguration : EntityTypeConfiguration<WagInSmgs>
    {
        public WagInSmgsConfiguration()
        {
            this.ToTable("WagInSmgs", "dbo");
            //primary key
            this.HasKey(p => p.WagonSmgsId);
            //Config one-to-many for SMGSNAKL
            this.HasRequired(t => t.SmgsNakl)
                .WithMany(t => t.WagInSmgses)
                .HasForeignKey(t => t.SmgsNaklId);

            //config one-to-many Wagon
            this.HasRequired(t => t.Wagon)
                .WithMany(t => t.WagInSmgses)
                .HasForeignKey(x => x.WgaonId);

            this.Ignore(p => p.MatrixWeigth);
            this.Ignore(p => p.SmgsMatrixWeigth);

            this.Ignore(p => p.MatrixSmgsBruttoDiff);
            this.Ignore(p => p.MatrixSmgsNettoDiff);

        }

    }
}
