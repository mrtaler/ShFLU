﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using ShFLU.DataBase.Table;

namespace ShFLY.DataBase.Table
{
    public class TaraBruttoForShflu
    {
        public int Id { get; set; }
        public virtual WagInSmgs WagonForWeigth { get; set; }
        public virtual MatrixWagon MatrixWagonTara { get; set; }
        public virtual MatrixWagon MatrixWagonBrutto { get; set; }

      //  public int  MatrixWagonTaraId { get; set; }
      //  public int  MatrixWagonBruttoId { get; set; }

    }
    public class TaraBruttoForShfluConfiguration : EntityTypeConfiguration<TaraBruttoForShflu>
    {
        /*public TaraBruttoForShfluConfiguration()
        {
            this.ToTable("TaraBruttoForShflu", "dbo");
            this.HasKey(t => t.Id);
            this.HasRequired(p => p.WagonForWeigth)
                .WithOptional(r => r.TaraBruttoWeigth);

          
            ///primary key


            /*   this.HasRequired(t => t.Wagon)
                   .WithMany(t => t.WagInSmgses)
                   .HasForeignKey(t => t.WagonSmgsId);

               this.HasRequired(t => t.SmgsNakl)
                  .WithMany(t => t.WagInSmgses)
                  .HasForeignKey(t => t.SmgsNaklWagId);
              
        }*/

    }
}
