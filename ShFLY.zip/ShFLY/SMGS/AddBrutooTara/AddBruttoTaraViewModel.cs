﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ShFLU.DataBase.Table;
using ShFLU.MVVM;
using ShFLY.SMGS.AddBrutooTara.FindWagonInMarix;
using ShFLY.DataBase.Table;
using ShFLU.DataBase;
using System.Windows;

namespace ShFLY.SMGS.AddBrutooTara
{
    public class AddBruttoTaraViewModel : ViewModelBase
    {
        private ShFluContext Context;
        public WagInSmgs WorkWagon { get; set; }
        public string ResultForWagon { get { return WorkWagon.MatrixWeigth.ToString(); } }
       private Window win;
        public ViewModelCommand SaveCommand { get; set; }
        public ViewModelCommand AddBruttoTaraCommand { get; set; }

        public AddBruttoTaraViewModel(WagInSmgs workWagon, ShFluContext context,Window win)
        {
            this.win = win;
            Context = context;
            WorkWagon = workWagon;
            SaveCommand = new ViewModelCommand(Save, true);
            AddBruttoTaraCommand = new ViewModelCommand(AddBruttoTara, true);
        }
        //private string ResultForWagonTB()
        //{
        //     int Brutto=0;
        //     int Tara=0;
        //     if (WorkWagon.MatrixWagonBrutto != null)
        //    {
        //        Brutto = Convert.ToInt32(WorkWagon.MatrixWagonBrutto.Weight);
        //    }
        //    if (WorkWagon.MatrixWagonTara != null)
        //    {

        //        Tara = Convert.ToInt32(WorkWagon.MatrixWagonTara.Weight);
        //    }
            
        //    return (
        //        (Brutto-Tara).ToString()
        //        );

        //}
        private void AddBruttoTara(object param)
        {
            string par = param.ToString();
            FindWagonInMarixView window = new FindWagonInMarixView(WorkWagon.Wagon.Nwag, par);
            window.ShowDialog();
            if (window.DialogResult == true)
            {


                MatrixWagon  resFind = (MatrixWagon)window.dataGrid1.SelectedItem;
                MatrixWagon sel1 = Context.MatrixWagonDbSet.Find(resFind.MatrixWagonId);
                
                if (sel1.Matrixx.MatrixType.Contains("rutt"))
                {
                       
                        WorkWagon.MatrixWagonBrutto = sel1;
                        NotifyPropertyChanged("WorkWagon");
                        NotifyPropertyChanged("ResultForWagon");
                }
                else if (sel1.Matrixx.MatrixType.Contains("Tara"))
                {
                        WorkWagon.MatrixWagonTara = sel1;
                        NotifyPropertyChanged("WorkWagon");
                        NotifyPropertyChanged("ResultForWagon");
                }
            }
        }
        private void Save(object param)
        {
            Context.SaveChanges();
            win.Close();
        }
    }
}
