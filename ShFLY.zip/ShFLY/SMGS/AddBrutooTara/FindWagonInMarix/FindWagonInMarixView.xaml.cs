﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ShFLY.SMGS.AddBrutooTara.FindWagonInMarix
{
    /// <summary>
    /// Логика взаимодействия для FindWagonInMarixView.xaml
    /// </summary>
    public partial class FindWagonInMarixView : Window
    {
        public FindWagonInMarixView(int numWag,string type)
        {
            DataContext = new FindWagonInMarixViewModel(numWag, type);
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            this.Close();
        }
    }
}
