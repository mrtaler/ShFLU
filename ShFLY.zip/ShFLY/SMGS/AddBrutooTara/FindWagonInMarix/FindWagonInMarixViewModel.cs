﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ShFLU.DataBase;
using ShFLU.DataBase.Table;

namespace ShFLY.SMGS.AddBrutooTara.FindWagonInMarix
{
  public  class FindWagonInMarixViewModel
    {
      private ShFluContext context;
      public List<MatrixWagon> MatrixWagonList { get; set; }
      public MatrixWagon SelectMatrixWagon { get; set; }
      public FindWagonInMarixViewModel(int numWag, string type)
      {
          context = new ShFluContext();
          MatrixWagonList=new List<MatrixWagon>(context.MatrixWagonDbSet.Where(p=>p.Matrixx.MatrixType==type).Where(p=>p.WagonNumberMatrix.Value==numWag));

      }
    }
}
