﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using ShFLU.DataBase.Table;
using ShFLU.DataBase;
using ShFLU.MVVM;
using System.Windows;
using ShFLY.SMGS.AddBrutooTara;

namespace ShFLY.SMGS.allsmgs
{
    public class allSmgsViewModel : ViewModelBase
    {
        private ShFluContext context;
        public ObservableCollection<SmgsNakl> AllSmgsNakl { get; set; }
        private SmgsNakl selectSmgs;
        public SmgsNakl SelectSmgs
        {
            get
            {
                return selectSmgs;
            }
            set
            {
                if (selectSmgs != value)
                {
                    selectSmgs = value;
                    NotifyPropertyChanged("AllWagInSmgs");
                    NotifyPropertyChanged("SelectSmgs");
                }
            }
        }
        public ObservableCollection<WagInSmgs> AllWagInSmgs
        {
            get
            {
                if (SelectSmgs!=null)
                {
                    return new ObservableCollection<WagInSmgs>(SelectSmgs.WagInSmgses); 
                }
                else
                {
                    return  null; 
                }
               
            }
        }
        public ViewModelCommand EditCommand { get; set; }
        public ViewModelCommand DeleteSmgsCommand { get; set; }
        public ViewModelCommand SaveCommand { get; set; }

        public allSmgsViewModel()
        {
            context = new ShFluContext();
            AllSmgsNakl = new ObservableCollection<SmgsNakl>(context.SmgsNaklDbSet);
            EditCommand = new ViewModelCommand(edit, true);
            DeleteSmgsCommand = new ViewModelCommand(DeleteSmgs, true);
            SaveCommand = new ViewModelCommand(Save, true);
        }
        private void edit(object param)
        {
            var pr = (WagInSmgs)param;
            AddBruttoTaraView window = new AddBruttoTaraView((WagInSmgs)param,context);
            window.ShowDialog();

            NotifyPropertyChanged("AllWagInSmgs");
     
        }
        private void DeleteSmgs(object param)
        {
            if (param!=null)
            {
                AllSmgsNakl.Remove((SmgsNakl)param);
                context.SmgsNaklDbSet.Remove((SmgsNakl)param);
                context.SaveChanges();
            }
           
        }
        private void Save(object param) {
            context.SaveChanges();
        }


    }
}
